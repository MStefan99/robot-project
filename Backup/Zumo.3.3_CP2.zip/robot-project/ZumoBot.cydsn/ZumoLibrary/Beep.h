#ifndef BEEP_H_
#define BEEP_H_
#include "project.h"

void Beep(uint32 length, uint8 pitch);

#endif 